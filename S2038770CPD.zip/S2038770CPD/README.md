# Cloud Project Implementation

This is the project implementation of a cloud project using AWS.